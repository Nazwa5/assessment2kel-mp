import 'package:flutter/material.dart';
// HomePage
import 'package:sumut_adventure/beranda.dart';
// Register
import 'package:sumut_adventure/Register/Register.dart';
// Login
import 'package:sumut_adventure/login/login.dart';
// Home Menu
import 'package:sumut_adventure/MainPage/Home.dart';
import 'package:sumut_adventure/MainPage/Home2.dart';
// Maps
import 'package:sumut_adventure/Maps/Maps.dart';
// Profile
import 'package:sumut_adventure/profile/profile.dart';
// Search
import 'package:sumut_adventure/search/search.dart';
import 'package:sumut_adventure/search/desc.dart';

void main() {
  runApp(const MyApp());
}

class AppTheme {
  static ThemeData get themeData {
    return ThemeData(
      appBarTheme: const AppBarTheme(
        color: Color(0xFFD8D7FE),
      ),
      scrollbarTheme: ScrollbarThemeData(
        thumbColor: MaterialStateProperty.all(Colors.transparent),
      ),
    );
  }
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: AppTheme.themeData,
      home: const DetailScreen(),
    );
  }
}
