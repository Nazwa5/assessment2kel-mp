import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class MapScreen extends StatefulWidget {
  const MapScreen({Key? key}) : super(key: key);
  @override
  _MapScreenState createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  late GoogleMapController mapController;

  final LatLng _center = const LatLng(2.6667, 98.6667);

  void _onMapCreated(GoogleMapController controller) {
    mapController = controller;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(25.0),
        child: AppBar(),
      ),
    );
  }
}
//       body: Column(
//         children: [
//           Expanded(
//             flex: 1,
//             child: GoogleMap(
//               onMapCreated: _onMapCreated,
//               initialCameraPosition: CameraPosition(
//                 target: _center,
//                 zoom: 10.0,
//               ),
//             ),
//           ),
//           const SizedBox(height: 20.0),
//           Expanded(
//             flex: 1,
//             child: Container(
//               color: Colors.white,
//               child: Column(
//                 children: [
//                   ListTile(
//                     title: const Text('Danau Toba'),
//                     subtitle: const Text('Kab. Simalungun, Sumatera Utara'),
//                     trailing: Row(
//                       mainAxisSize: MainAxisSize.min,
//                       children: [
//                         ElevatedButton(
//                           onPressed: () {},
//                           child: const Text('Rute'),
//                         ),
//                         const SizedBox(width: 8),
//                         ElevatedButton(
//                           onPressed: () {},
//                           child: const Text('Mulai'),
//                         ),
//                         const SizedBox(width: 8),
//                         IconButton(
//                           icon: const Icon(Icons.bookmark_border),
//                           onPressed: () {},
//                         ),
//                       ],
//                     ),
//                   ),
//                   const SizedBox(height: 15.0),
//                   SingleChildScrollView(
//                     scrollDirection: Axis.horizontal,
//                     child: Row(
//                       children: [
//                         _buildDestinationCard('assets/image/image 2.png'),
//                         _buildDestinationCard('assets/image/image 3.png'),
//                         _buildDestinationCard('assets/image/image 4.png'),
//                         _buildDestinationCard('assets/image/image 5.png'),
//                       ],
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   Widget _buildDestinationCard(String imagePath) {
//     return Padding(
//       padding: const EdgeInsets.symmetric(horizontal: 18),
//       child: Stack(
//         children: [
//           ClipRRect(
//             borderRadius: BorderRadius.circular(6.0),
//             child: Image.asset(
//               imagePath,
//               width: 290,
//               height: 180,
//               fit: BoxFit.cover,
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }
