import 'package:flutter/material.dart';

class DetailScreen extends StatefulWidget {
  const DetailScreen({Key? key}) : super(key: key);

  @override
  _DetailScreen createState() => _DetailScreen();
}

class _DetailScreen extends State<DetailScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(25.0),
        child: AppBar(),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Image.asset(
                'assets/image/danau-toba.png', // Replace with your image path
                height: 200,
                width: double.infinity,
                fit: BoxFit.cover,
              ),
              const SizedBox(height: 8),
              const Text(
                'Danau Toba',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              const Text(
                'Simalungun',
                style: TextStyle(color: Colors.grey),
              ),
              const Row(
                children: [
                  Icon(Icons.star, color: Colors.yellow),
                  Text('4.8 (343)'),
                ],
              ),
              const SizedBox(height: 8),
              const Text(
                'Danau Toba di Sumatera Utara, danau vulkanik terbesar di dunia, terbentuk 74,000 tahun lalu. Dengan luas 1145 km² dan Pulau Samosir di tengahnya, danau ini menawarkan pemandangan indah, budaya Batak Toba, serta beragam aktivitas wisata.',
              ),
              const SizedBox(height: 16),
              const Text(
                'Aktivitas di Danau Toba',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    activityCard('Jet ski', 'assets/image/image 2.png',
                        'Personal watercraft ini, istime.'),
                    activityCard(
                        'Kapal Penyeberangan',
                        'assets/image/image 3.png',
                        'Kapal pinisi ini adalah yang per.'),
                    activityCard('Aktivitas 3', 'assets/image/image 4.png',
                        'Deskripsi aktivitas 3'),
                    activityCard('Aktivitas 4', 'assets/image/image 5.png',
                        'Deskripsi aktivitas 4'),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              const Text(
                'Destinasi favorit',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    destinationCard(
                        'Aek Sijorni', 'assets/image/aek-sijorni.png'),
                    destinationCard('Air Terjun Sipiso-piso',
                        'assets/image/air-terjun-sipiso-piso.png'),
                    destinationCard(
                        'Danau Toba', 'assets/image/danau-toba1.png'),
                    destinationCard('Lumbini Natural Park',
                        'assets/image/lumbini-natural-park.png'),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              const Text(
                'Souvenir',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    souvenirCard('Kain Ulos', 'assets/image/image 6.png'),
                    souvenirCard('Aksesoris Khas', 'assets/image/image 7.png'),
                    souvenirCard('Souvenir 3', 'assets/image/image 8.png'),
                    souvenirCard('Souvenir 4', 'assets/image/image 9.png'),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              Center(
                child: ElevatedButton.icon(
                  onPressed: () {
                    // Handle help button
                  },
                  icon: const Icon(Icons.help),
                  label: const Text('Butuh Bantuan?'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget activityCard(String title, String imagePath, String description) {
    return Container(
      width: 150,
      margin: const EdgeInsets.only(right: 8),
      child: Stack(
        children: [
          Card(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Image.asset(
                  imagePath,
                  height: 100,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(title),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8.0),
                  child: Text(
                    description,
                    style: const TextStyle(fontSize: 12),
                  ),
                ),
              ],
            ),
          ),
          const Positioned(
            bottom: 45,
            right: 8,
            child: Icon(Icons.favorite_border, color: Colors.grey),
          ),
        ],
      ),
    );
  }

  Widget destinationCard(String title, String imagePath) {
    return Container(
      width: 200,
      margin: const EdgeInsets.only(right: 8),
      child: Card(
        child: Stack(
          children: [
            Image.asset(
              imagePath,
              height: 150,
              width: double.infinity,
              fit: BoxFit.cover,
            ),
            Positioned(
              bottom: 8,
              left: 8,
              child: Text(
                title,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget souvenirCard(String title, String imagePath) {
    return Container(
      width: 150,
      margin: const EdgeInsets.only(right: 8),
      child: Card(
        child: Stack(
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Image.asset(
                  imagePath,
                  height: 100,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(title),
                ),
              ],
            ),
            Positioned(
              bottom: 8,
              left: 8,
              child: Text(
                title,
                style: const TextStyle(
                  color: Colors.black,
                  backgroundColor: Colors.white70,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
